"""Management package for news_app."""
