"""
news_app package initialization.

Defines the default app config for Django application registry.
"""
DEFAULT_APP_CONFIG = 'news_app.apps.NewsAppConfig'
